<?php
require '../admin/dbconnect.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="./index.js"></script>
    <script src="https://kit.fontawesome.com/fd5c7e34ad.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./CSS/index.css">
    <title>RLS AMU</title>
</head>

<body>
    <div class="container1">
        <div class="header">
            <div class="logo"><img src="./Images/RLS LOGO.png" alt=""></div>
            <div class="name">
                <div class="r">
                    <img src="./Images/R.png" alt="">
                </div>
                <div class="title">
                    <h1>ALEIGH LITERARY SOCIETY</h1>
                </div>
            </div>
            <div class="links">
                <div class="insta"><img class="insta-img" src="./Images/INSTA LOGO.png" alt=""></div>
                <div class="menu" id="menu-btn" onclick="btnaction()"><img class="menu-img"
                        src="./Images/OPTIONS LOGO.png" alt=""></div>
                <div class="nav-panel" id="nav">
                    <a href="./index.php">Home</a>
                    <a href="about.html">About Us</a>
                    <button class="linkbtn" onclick="linkaction()">Write-Ups</button>
                    <!-- <a href="null" onclick="linkaction()">Write-Ups</a> -->
                    <a href="./event_gallery.html">Event Gallery</a>
                    <a href="./founders.html">Founder's Page</a>
                    <a href="./contactus.html">Contact Us</a>
                    <a href="./form.html">Submit Your Work</a>
                </div>
                <div class="nav-panel side-panel" id="side-nav">
                    <a href="./articles.php">Articles</a>
                    <a href="./prose.php">Prose</a>
                    <a href="./poetry.php">Poetry</a>
                </div>
            </div>
        </div>
        <div class="blocks">
            <div class="box">
                <img src="./Images/image (1).jpg" alt="">
            </div>
            <div class="box">
                <img src="./Images/image (2).jpg" alt="">
            </div>
            <div class="box">
                <img src="./Images/image (3).jpg" alt="">
            </div>
            <div class="box">
                <img src="./Images/image (4).jpg" alt="">
            </div>
        </div>
        <div class="blocks">
            <div class="label">
                <a href="./articles.html">ARTICLES</a>
            </div>
            <div class="label">
                <a href="./prose.html">PROSE</a>
            </div>
            <div class="label">
                <a href="./poetry.html">POETRY</a>
            </div>
            <div class="label">
                <a href="./event_gallery.html">EVENT GALLERY</a>
            </div>
        </div>
    </div>
    <div class="container2">
        <div class="content">
            <h2>WeAre</h2>
            <p>The Literary Society of Shaheed Sukhdev College of Business Studies (aka LitSoc), a collection of
                diverse, yet like-minded individuals who come together to create a safe space, a place where they
                can forget about their worldly worries and express themselves freely.
                Through this blog, we aim to provide a publishing platform not only for ourselves but also for all
                students everywhere</p>
        </div>

        <div class="container3">
            <h1>Recently Published</h1>
            <div class="blocks2">
                <?php
                  $sql="Select * from poems ORDER BY timestamp DESC limit 2 ";
                  $result=mysqli_query($conn,$sql);
                  while ($row=mysqli_fetch_assoc($result)) {
                      echo ' <div class="box2"><a href="#"><img src="../admin/upload/'. $row['cover_image'].'" alt="image"></a></div>';
                
                }
                 
                $sql="Select * from articles ORDER BY timestamp DESC limit 2 ";
                $result=mysqli_query($conn,$sql);
                while ($row=mysqli_fetch_assoc($result)) {
                    echo ' <div class="box2"><a href="#"><img src="../admin/upload/'. $row['cover_image'].'" alt="image"></a></div>';
              
              }

              $sql="Select * from proses ORDER BY timestamp DESC limit 2 ";
              $result=mysqli_query($conn,$sql);
              while ($row=mysqli_fetch_assoc($result)) {
                  echo ' <div class="box2"><a href="#"><img src="../admin/upload/'. $row['cover_image'].'" alt="image"></a></div>';
            
            }


                ?>
                
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="logo"><img src="./Images/AMU LOGO.png" alt=""></div>
        <div class="subscribe-box">
            <h2>CONTACT US</h2>
            <!-- <input type="email" name="email" id="email" placeholder="Enter your mail here"></input>
            <button>Subscribe Now</button> -->
            <a href="mailto:raleighls.amu@gmail.com">raleighls.amu@gmail.com</a>
            <a href="https://www.instagram.com/raleigh.amu/"><i class="fa fa-instagram"></i> @raleigh.amu</a>
        </div>
        <div class="logo"><img src="./Images/RLS LOGO.png" alt=""></div>
    </div>
</body>

</html>