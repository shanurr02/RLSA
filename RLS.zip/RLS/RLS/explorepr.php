<?php
require '../admin/dbconnect.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="https://kit.fontawesome.com/fd5c7e34ad.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./CSS/explore.css">
    <script src="./index.js"></script>
    <title>Explore Proses</title>
</head>

<body>
    <div class="container1">
        <div class="header">
            <div class="logo"><img src="./Images/RLS LOGO.png" alt=""></div>
            <div class="name">
                <div class="r">
                    <img src="./Images/R.png" alt="">
                </div>
                <div class="title">
                    <h1>ALEIGH LITERARY SOCIETY</h1>
                </div>
            </div>
            <div class="links">
                <div class="insta"><img class="insta-img" src="./Images/INSTA LOGO.png" alt=""></div>
                <div class="menu" id="menu-btn" onclick="btnaction()"><img class="menu-img"
                        src="./Images/OPTIONS LOGO.png" alt=""></div>
                <div class="nav-panel" id="nav">
                    <a href="./index.html">Home</a>
                    <a href="about.html">About Us</a>
                    <button class="linkbtn" onclick="linkaction()">Write-Ups</button>
                    <!-- <a href="null" onclick="linkaction()">Write-Ups</a> -->
                    <a href="./event_gallery.html">Event Gallery</a>
                    <a href="./founders.html">Founder's Page</a>
                    <a href="./contactus.html">Contact Us</a>
                    <a href="./form.html">Submit Your Work</a>
                </div>
                <div class="nav-panel side-panel" id="side-nav">
                    <a href="./articles.html">Articles</a>
                    <a href="./prose.html">Prose</a>
                    <a href="./poetry.html">Poetry</a>
                </div>
            </div>
        </div>
    </div>
    <div class="containerx">
        <h1 class="explore">EXPLORE PROSE</h1>
    </div>
    <div class="sort">
        <h4>Refine by: </h4>
        <button class="refine">ALL</button>
        <button class="refine">A</button>
        <button class="refine">B</button>
        <button class="refine">C</button>
        <button class="refine">D</button>
        <button class="refine">E</button>
        <button class="refine">F</button>
        <button class="refine">G</button>
        <button class="refine">H</button>
        <button class="refine">I</button>
        <button class="refine">J</button>
        <button class="refine">K</button>
        <button class="refine">L</button>
        <button class="refine">M</button>
        <button class="refine">N</button>
        <button class="refine">O</button>
        <button class="refine">P</button>
        <button class="refine">Q</button>
        <button class="refine">R</button>
        <button class="refine">S</button>
        <button class="refine">T</button>
        <button class="refine">U</button>
        <button class="refine">V</button>
        <button class="refine">W</button>
        <button class="refine">X</button>
        <button class="refine">Y</button>
        <button class="refine">Z</button>
        <label for="view">Sort By:</label>
        <select name="view" id="view">
            <option value="date">Date</option>
            <option value="author">Author</option>
        </select>
    </div>
    <div class="container">
    <?php
         $sql="Select * from proses ORDER BY timestamp DESC limit 20 ";
         $result=mysqli_query($conn,$sql);
         while ($row=mysqli_fetch_assoc($result)) {

            echo ' <a href="./individual_prose.php?prose_id='. $row['prose_id'] .'" >
            <div class="content">
                <h3 class="title">'. $row['title'].'</h3>
                <h4 class="author">BY- '. $row['author'].' </h4>
            </div>
        </a>';
         }
        
        ?>
    </div>
    <hr>
    <div class="footer">
        <div class="logo"><img src="./Images/AMU LOGO.png" alt=""></div>
        <div class="subscribe-box">
            <h2>CONTACT US</h2>
            <!-- <input type="email" name="email" id="email" placeholder="Enter your mail here"></input>
            <button>Subscribe Now</button> -->
            <a href="mailto:raleighls.amu@gmail.com">raleighls.amu@gmail.com</a>
            <a href="https://www.instagram.com/raleigh.amu/"><i class="fa fa-instagram"></i> @raleigh.amu</a>
        </div>
        <div class="logo"><img src="./Images/RLS LOGO.png" alt=""></div>
    </div>'
</body>

</html>