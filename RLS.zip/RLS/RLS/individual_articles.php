<?php
require '../admin/dbconnect.php';

if($_SERVER['REQUEST_METHOD']=="GET"){
    IF(isset($_GET['article_id'])){
        $article_id=$_GET['article_id'];

    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./CSS/individual_articles.css">
    <script src="./index.js"></script>
    <script src="https://kit.fontawesome.com/fd5c7e34ad.js" crossorigin="anonymous"></script>
    <title><?php
    $sql="Select * from articles where article_id=$article_id ";
    $result=mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($result);
    $title=$row['title'];
    echo "RLS -" .$title;
    ?></title>
</head>

<body>
    <div class="container1">
        <div class="header">
            <div class="logo"><img src="./Images/RLS LOGO.png" alt=""></div>
            <div class="name">
                <div class="r">
                    <img src="./Images/R.png" alt="">
                </div>
                <div class="title">
                    <h1>ALEIGH LITERARY SOCIETY</h1>
                </div>
            </div>
            <div class="links">
                <div class="insta"><img class="insta-img" src="./Images/INSTA LOGO.png" alt=""></div>
                <div class="menu" id="menu-btn" onclick="btnaction()"><img class="menu-img"
                        src="./Images/OPTIONS LOGO.png" alt=""></div>
                <div class="nav-panel" id="nav">
                    <a href="./index.html">Home</a>
                    <a href="about.html">About Us</a>
                    <button class="linkbtn" onclick="linkaction()">Write-Ups</button>
                    <!-- <a href="null" onclick="linkaction()">Write-Ups</a> -->
                    <a href="./event_gallery.html">Event Gallery</a>
                    <a href="./founders.html">Founder's Page</a>
                    <a href="./contactus.html">Contact Us</a>
                    <a href="./form.html">Submit Your Work</a>
                </div>
                <div class="nav-panel side-panel" id="side-nav">
                    <a href="./articles.html">Articles</a>
                    <a href="./prose.html">Prose</a>
                    <a href="./poetry.html">Poetry</a>
                </div>
            </div>
        </div>
    </div>
    <div class="tag" id="tag">
        <div class="details">
        <?php
                  $sql="Select * from articles where article_id=$article_id ";
                  $result=mysqli_query($conn,$sql);
                  $row=mysqli_fetch_assoc($result);
                  $title=$row['title'];
                  $author=$row['author'];
                  $desc=$row['desc'];
                  $article=$row['article'];
                  $cover_image=$row['cover_image'];
                //   echo $title;
                //   exit;

                echo '<h1> '. $title .' </h1>
                <p>  '. $desc .' </p>
            </div>
            <div class="author">
                <p>By- '.  $author .'</p>
            </div>
        </div>
        <div class="container">
            <div class="article-img" id="article-img">
                <img  src="../admin/upload/'. $cover_image .'" alt="">
            </div>
            <div class="content">
                <p class="article" id="article">
                '.$row['article'] .'
                </p>
            </div>';
                 
                ?>
            
    </div>
    <hr>
    <div class="container2">
        <div class="img-card">
            <img src="./Images/kaneki.jpeg" alt="">
            <h5>TUHEL AHMED</h5>
            <p>PR INCHARGE</p>
            <p>RALEIGH LITERARY SOCIETY</p>
        </div>
        <p class="dialog">Th e l a t e st a d d iti o n t o t h e LitSo c a rs e n a l is o u r v e r y own b l o g . Th
            is b l o g is
            a me d i um f o r p e o p l e
            t o e x p r e ss t h ems e l v e s fr e e l y , a p l a c e f o r t h em t o s h owc a s e t h e ir c r e a
            ti v it y . It’s a p l a c e t o
            c a p t u r e t h e p e rs o n a liti e s t h a t p a ss t h r o u g h t h e h a lls o f t h is c o ll e g e
            ; a ll o f t h em i n a si n g u l a r
            q u e st f o r s u c c e ss y e t d e fi n e d b y a u n i q u e s e t o f i d e a s t h r o u g h wh i c h
            t h e y v i ew t h e wo rl d .
            Th r o u g h t h is me d i um, we h o p e t o i n s p ir e a n d g e t i n s p ir e d .</p>
    </div>
    <hr>
    <div class="footer">
        <div class="logo"><img src="./Images/AMU LOGO.png" alt=""></div>
        <div class="subscribe-box">
            <h2>CONTACT US</h2>
            <!-- <input type="email" name="email" id="email" placeholder="Enter your mail here"></input>
            <button>Subscribe Now</button> -->
            <a href="mailto:raleighls.amu@gmail.com">raleighls.amu@gmail.com</a>
            <a href="https://www.instagram.com/raleigh.amu/"><i class="fa fa-instagram"></i> @raleigh.amu</a>
        </div>
        <div class="logo"><img src="./Images/RLS LOGO.png" alt=""></div>
    </div>
    <hr>
</body>

</html>