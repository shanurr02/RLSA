<?php
require '../admin/dbconnect.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/fd5c7e34ad.js" crossorigin="anonymous"></script>
    <script src="./index.js"></script>
    <link rel="stylesheet" href="./CSS/prose.css">
    <title>RLS -Prose</title>
</head>

<body>
    <div class="header">
        <div class="logo"><img src="./Images/RLS LOGO.png" alt=""></div>
        <div class="name">
            <div class="r">
                <img src="./Images/R.png" alt="">
            </div>
            <div class="title">
                <h1>ALEIGH LITERARY SOCIETY</h1>
            </div>
        </div>
        <div class="links">
            <div class="insta"><img class="insta-img" src="./Images/INSTA LOGO.png" alt=""></div>
            <div class="menu" id="menu-btn" onclick="btnaction()"><img class="menu-img" src="./Images/OPTIONS LOGO.png"
                    alt=""></div>
            <div class="nav-panel" id="nav">
                <a href="./index.html">Home</a>
                <a href="about.html">About Us</a>
                <button class="linkbtn" onclick="linkaction()">Write-Ups</button>
                <!-- <a href="null" onclick="linkaction()">Write-Ups</a> -->
                <a href=".event_gallery.html">Event Gallery</a>
                <a href="./founders.html">Founder's Page</a>
                <a href="./contactus.html">Contact Us</a>
                <a href="./form.html">Submit Your Work</a>
            </div>
            <div class="nav-panel side-panel" id="side-nav">
                <a href="./articles.php">Articles</a>
                <a href="">Prose</a>
                <a href="./poetry.php">Poetry</a>
            </div>

        </div>
    </div>
    <div class="container">
        <h1 class="prose">
            <p>a</p>PROSE
        </h1>
    </div>


    <div class="container1">
        <h1 class="featured-works">FEATURED WORKS</h1>

        <?php
        $sql="Select * from proses WHERE featured='YES' ORDER BY timestamp DESC limit 2 ";
        $result=mysqli_query($conn,$sql);

      while(  $row1=mysqli_fetch_assoc($result)){
        $prose_part= substr( $row1['prose'], 0,30);
        $title_part= substr( $row1['title'],0, 10);
        echo '<div class="box1">

        <div class="image">
            <img src="../admin/upload/'. $row1['cover_image'].'" alt="">
        </div>

        <div class="details">
            <div class="heading">
                <p>'. $title_part. '</p>
            </div>
            <div class="para">
                <p>'. $prose_part. '</p>
                <a href="./individual_prose.php?prose_id='. $row1['prose_id'] .'" ><i>Read more...</i></a>
            </div>
        </div>
    </div>';
      }
     

//     $row2=mysqli_fetch_assoc($result);
//     $article_part= substr( $row2['prose'], 0,30);
//     $title_part= substr( $row2['title'],0, 10);


//     echo '<div class="box11">


//     <div class="details">
//         <div class="heading">
//             <p>'. $title_part. '</p>
//         </div>
//         <div class="para">
//             <p>'. $article_part.'</p>
//             <a href="./individual_articles.php?prose_id='. $row2['prose_id'] .'" ><i>Read more...</i></a>
//         </div>
//     </div>
//     <div class="image">
//         <img  src="../admin/upload/'. $row2['cover_image'].'"   alt="">
//     </div>
// </div>';

      
        
        ?>
    </div>

    <div class="container2">
        <h1 class="recently-published">RECENTLY PUBLISHED</h1>

        <div class="container3">
        <?php
        $sql="Select * from proses ORDER BY timestamp DESC limit 6 ";
        $result=mysqli_query($conn,$sql);
        while ($row=mysqli_fetch_assoc($result)) {
           $prose_part= substr( $row['prose'], 0,30);
           $title_part= substr( $row['title'],0, 10);
        
        echo '  <div class="box">
        <div class="box-img">
            <img src="../admin/upload/'. $row['cover_image'].'" alt="">
        </div>
        <div class="box-details">
            <div class="box-heading">'. $title_part .'...</div>
            <div class="box-creator">BY - '. $row['author'] .'</div>
        </div>

        <div class="box-para">
            <p>'. $prose_part .' ...</p>
            <ahref="./individual_prose.php?poem_id='. $row['prose_id'] .'"><i>Read more...</i></ahref=>
        </div>
    </div>';}
    
        ?>
        </div>
    </div>

    <div class="browse-btn-box">
        <a href="./explorepr.php" class="browse">BROWSE ALL PROSE</a>
    </div>

    <hr>
    <div class="footer">
        <div class="logo"><img src="./Images/AMU LOGO.png" alt=""></div>
        <div class="subscribe-box">
            <h2>CONTACT US</h2>
            <!-- <input type="email" name="email" id="email" placeholder="Enter your mail here"></input>
            <button>Subscribe Now</button> -->
            <a href="mailto:raleighls.amu@gmail.com">raleighls.amu@gmail.com</a>
            <a href="https://www.instagram.com/raleigh.amu/"><i class="fa fa-instagram"></i> @raleigh.amu</a>
        </div>
        <div class="logo"><img src="./Images/RLS LOGO.png" alt=""></div>
    </div>
</body>

</html>