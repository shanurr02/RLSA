<?php

require './dbconnect.php';

session_start();
session_unset();
session_destroy();


header('location:/RLSBackend/index.php');


?>