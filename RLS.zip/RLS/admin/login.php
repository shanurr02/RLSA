<?php

require './dbconnect.php';

$invalid_user=false;


if ($_SERVER['REQUEST_METHOD']=='POST') {
    
     $enrollmentno=$_POST['enrollmentno'];
     $password=$_POST['password'];
    

    $sql ="select * from users where enrollmentno='$enrollmentno'";

    $result=mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($result);

    $hashed=$row['password'];
    $name=$row['name'];
    $user_id=$row['user_id'];
    // var_dump($hashed);
    echo "<br>";
    // var_dump(password_hash($password,PASSWORD_DEFAULT));
    // $pass_verify=password_verify($password,$hashed);
    // var_dump($pass_verify);

    //Test Login (Deleted After test)
    $pass_verify=($password==$hashed)?true:false;

    // exit;
    if ($pass_verify) {
        session_start();
        $_SESSION['user_id']=$user_id;
        $_SESSION['loggedin']=true;
        $_SESSION['enrollmentno']=$enrollmentno;
        // echo "Logged in successfully!";
        header('location:/RLS/admin/form.php');
    }
    else{
        $invalid_user=true;
        header('location:/RLS/admin/index.php?invalid_user='.$invalid_user);
    }


 }


?>